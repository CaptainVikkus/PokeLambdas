import json
import boto3

def lambda_handler(event, context):
    # Database
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Pokemon_Trainers')
    # Get Player
    player = event["queryStringParameters"]["Player"]
    pokemon = event["queryStringParameters"]["Pokemon"]
    health = event["queryStringParameters"]["Health"]
    level = event["queryStringParameters"]["Level"];
    
    #Update Player
    response = table.update_item(
        Key = {'Player': player},
        UpdateExpression="SET #Pokemon=:p, #Health=:h, #Level=:l",
        ExpressionAttributeValues={
            ':p': pokemon, 
            ':h': health, 
            ':l': level},
        ExpressionAttributeNames={
            '#Pokemon': 'Pokemon',
            '#Health': 'Health',
            '#Level': 'Level'},
        ReturnValues= "UPDATED_NEW")

    return {
            'statusCode': 200,
            'body' : json.dumps("Saved Player")
    }
