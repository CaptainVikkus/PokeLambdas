import json
import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    # Database
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Pokemon_Trainers')
    # USERID
    player = event["queryStringParameters"]["Player"]
    
    #Search Player
    response = table.get_item(Key={'Player': player})
    try:
        item = response['Item']
    except Exception as e:
         #New Player
        return  {
            'statusCode': 200,
            'body' : player
        }
    else:
        #Return Player from DB
        return {
            'statusCode': 200,
            'body' : json.dumps(item)
        }
